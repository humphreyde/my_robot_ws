
#include "ros/ros.h"
#include "std_msgs/String.h" //use data struct of std_msgs/String  
#include "linux_serial.h"

#include "baxter_core_msgs/JointCommand.h"


//test send value
float test_send_joint[7]   = {0.000000, 0.000000, 0.00000, 0.000000, 0.000000, 0.000000,  0.000000 };
unsigned char testSend3=0x05;

//test receive value
float test_rev_joint[7]   = {0};

unsigned char testRece4=0x00;


/*********************************回调函数***********************************/
//关节控制回调函数
void leftArmController_Callback(const baxter_core_msgs::JointCommand & msg)
{
  for(int i=0;i<7;i++)
  {
    test_send_joint[i] = msg.command[i];
  }
}


int main(int agrc,char **argv)
{
    ros::init(agrc,argv,"usart_send");
    ros::NodeHandle nh;

    ros::Subscriber leftarm_controller_sub = nh.subscribe("/robot/controller", 1000, &leftArmController_Callback);
    ros::Rate loop_rate(10);
    
    //串口初始化
    serialInit();

    while(ros::ok())
    {
        ros::spinOnce();
        //向STM32端发送数据，float类型，最后一个为unsigned char类型
	    writePosition(test_send_joint[0],test_send_joint[1],test_send_joint[2],test_send_joint[3],test_send_joint[4],test_send_joint[5],test_send_joint[6],testSend3);
        //从STM32接收数据，输入参数依次转化为小车的线速度、角速度、航向角（角度）、预留控制位
	   // readSpeed(testRece1,testRece2,testRece3,testRece4);
        //打印数据
	   ROS_INFO("%f,%f,%f,%f,%f,%f,%f\n",test_send_joint[0],test_send_joint[1],test_send_joint[2],test_send_joint[3],test_send_joint[4],test_send_joint[5],test_send_joint[6]);

        loop_rate.sleep();
    }
    return 0;
}
 



