#include "ros/ros.h"
#include "rosgraph_msgs/Clock.h"
#include "webots_api/webots.h"
#include "webots_api/position_random.h"
#include <vector>
#include <geometry_msgs/Twist.h>
#include "std_msgs/String.h"
#include <sstream>
#include <stdlib.h>
#include <time.h>

webots_api::WebotsApi webots_api_;

int main(int argc, char **argv)
{

  ros::init(argc, argv, "webots", ros::init_options::AnonymousName);

  ros::NodeHandle n;

  ros::Publisher sim_time_pub_ = n.advertise<rosgraph_msgs::Clock>("/clock", 1);
  ros::Publisher left_extra_rgb_pub_ = n.advertise<sensor_msgs::Image>("/camera/LeftExtraRGB", 10);
  ros::Publisher left_extra_depth_pub_ = n.advertise<sensor_msgs::Image>("/camera/LeftExtraDepth", 10);
  ros::Publisher right_extra_rgb_pub_ = n.advertise<sensor_msgs::Image>("/camera/RightExtraRGB", 10);
  ros::Publisher right_extra_depth_pub_ = n.advertise<sensor_msgs::Image>("/camera/RightExtraDepth", 10);

  //simulation time
  rosgraph_msgs::Clock sim_time;
  ros::Time time_ros_pub_(0,0);
  sim_time.clock.nsec = 0;
  sim_time.clock.sec  = 0;
  ros::Duration one_ms(0, 1e6);

  ros::Rate loop_rate(1000);

  double time_sim = 0;

  webots_api_.CameraApiInit();
    
  //simulation two iterations to avoid the error feedback
  wb_robot_step(1);
  wb_robot_step(1);

  int count = 0;//publish camera 32hz
  while (ros::ok())
  {
    time_sim += 0.001;
   //控制器容易崩溃

    sim_time.clock += one_ms;
    time_ros_pub_ += one_ms;
    if(sim_time.clock.nsec>=1e9)
    {
       sim_time.clock.nsec -= 1e9;
       sim_time.clock.sec += 1;
    }
    //30Hz publish
    if(count > 30){

      //camera publish
      webots_api_.cameraLeftExtraRGB(webots_api_.imageLeftExtraRGB_);
      webots_api_.imageLeftExtraRGB_.header.stamp = time_ros_pub_;
      left_extra_rgb_pub_.publish(webots_api_.imageLeftExtraRGB_);

      webots_api_.cameraLeftExtraDepth(webots_api_.imageLeftExtraDepth_);
      webots_api_.imageLeftExtraDepth_.header.stamp = time_ros_pub_;
      left_extra_depth_pub_.publish(webots_api_.imageLeftExtraDepth_);      

      webots_api_.cameraRightExtraRGB(webots_api_.imageRightExtraRGB_);
      webots_api_.imageRightExtraRGB_.header.stamp = time_ros_pub_;
      right_extra_rgb_pub_.publish(webots_api_.imageRightExtraRGB_);

      webots_api_.cameraRightExtraDepth(webots_api_.imageRightExtraDepth_);
      webots_api_.imageRightExtraDepth_.header.stamp = time_ros_pub_;
      right_extra_depth_pub_.publish(webots_api_.imageRightExtraDepth_);  
      count = 0;
    }else{
      count++;
    }
    wb_robot_step(1);
    ros::spinOnce();
    loop_rate.sleep();

  }

  return 0;
}


// %EndTag(FULLTEXT)%
